create definer = root@localhost trigger after_update_mark_resources_result
    after update
    on resources_result
    for each row
BEGIN
    DECLARE user_id,resource_id,category_id,count_row ,count_lessons,level_id,user_class INT;
    DECLARE avg_category DOUBLE;
    DECLARE  percent DOUBLE default 0.0;

    select `resources_result`.`resource_id`, `resources_result`.`user_id`,  `resources_result`.`category_id` ,`resources_result`.`level_id`,`users`.`class`
    INTO resource_id ,user_id,category_id,level_id,user_class from `resources_result`
                                                                       join `users` on  `users`.`userid` =`resources_result`.`user_id`
    where id=NEW.id;

    select count(*) into count_lessons from `lessons` where
            `lessons`.`category`=category_id and
            `lessons`.`id` in (select  `id_lesson` from `lessonassigns` where
            (`assigntype`='class' and  `id_target`=user_class) or
            (`assigntype`='student' and  `id_target`=user_id) or
            (`assigntype`='group' and  `id_target` in (select  `product_id` from `assigns`
                                                       where
                                                               `ref_type`='student' and
                                                               `product_type`='group' and
                                                               `ref_id`=user_id)));

    SELECT   sum(result)/(count_lessons) , sum(`resources_result`.`percent`)/(count_lessons) into
        avg_category ,percent from `resources_result` WHERE  `resources_result`.`user_id`=user_id and  `resources_result`.`category_id`=category_id ;
    select count(*)   into count_row from  `marks_user_categories` where
            `marks_user_categories`.`category_id`= category_id and `marks_user_categories`.`user_id`= user_id;

    IF  (0 = count_row) THEN
        INSERT INTO `marks_user_categories` (`id`, `user_id`, `category_id`, `result`, `percent`, `level_id`,`count_badges`, `created_at`, `updated_at`)
        VALUES (NULL, user_id , category_id ,avg_category, percent , '1' ,level_id, curdate(), curdate());

    ELSE
        update `marks_user_categories` set `result`= avg_category ,  `percent`=   percent  , `level_id`=level_id , `count_badges`=1 , `updated_at`=curdate()
        where  `marks_user_categories`.`category_id`= category_id and `marks_user_categories`.`user_id`= user_id;
    END IF;
END;

