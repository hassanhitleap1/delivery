create definer = root@localhost trigger after_update_mark_lesson
    after update
    on result_media
    for each row
BEGIN
    DECLARE id_user,lesson_id,count_row,category_id ,count_media,count_percent,level_id INT;
    DECLARE  max DOUBLE default 100;
    DECLARE avg_lesson  DOUBLE;
    DECLARE  percent DOUBLE default 0.0;

    select `result_media`.`user_id`, `result_media`.`lesson_id`,`lessons`.`category`,`lessons`.`level`
    INTO id_user,lesson_id,category_id,level_id from `result_media`
                                                         inner join `lessons` on
            `lessons`.`id` =`result_media`.`lesson_id`  where `result_media`.`id`=NEW.id;

    select count(*)   into count_row from  `resources_result` where
            `resources_result`.`type`= 1  and `resources_result`.`resource_id`= lesson_id and `resources_result`.`user_id`=id_user and `type`=1;
    select count(*) into count_media from `lesson_media`  where `lesson_media`.`id_lesson`= lesson_id;

    SELECT  sum(result)/count_media into avg_lesson  from `result_media` WHERE `result_media`.`user_id`=id_user and  `result_media`.`lesson_id`=lesson_id ;
    select count(*) into count_percent from `result_media`  where
            `result_media`.`lesson_id`= lesson_id and  `result_media`.`user_id`=id_user;

    SELECT  (count(*)/count_media) * 100   into percent  from `result_media` WHERE `result_media`.`user_id`=id_user and  `result_media`.`lesson_id`=lesson_id ;


    IF  (0 = count_row) THEN
        INSERT INTO `resources_result` (`id`, `type`, `user_id`, `resource_id`, `result`, `percent`, `max`,`count_badges`,`category_id`, `level_id`,`created_at`, `updated_at`)
        VALUES (NULL, '1', id_user,lesson_id, avg_lesson , percent , '0',max,category_id,level_id, curdate(), curdate());
    ELSE
        update `resources_result` set `result`= avg_lesson ,  `percent`=   percent  ,  `count_badges`=1 , `category_id`=category_id ,`level_id`=level_id,`updated_at`=curdate()
        where `resources_result`.`type`=1 and `resources_result`.`resource_id`=lesson_id and `resources_result`.`user_id`=id_user;
    END IF;
END;

